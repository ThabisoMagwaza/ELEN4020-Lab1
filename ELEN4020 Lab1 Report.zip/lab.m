% Christian Kamwangla 685344
% Godknows Musa 553196
% RSA implementation

% p and q are generated from the function keyGen
[p q] = primeGen(); 
n = p * q;
phin = (p - 1) * (q - 1);

% Randomly choose s
gcd = 0;
% make sure that s and the totient phiM are comprime then return private
% key h (killing two birds with one stone
while (gcd ~= 1)
     s = randi([2,2^16],1,1);
    [gcd h] = extendedEclud(s,phin);
end
% check if s*h mod phiM = 1
if myMod(s*h,1,phin) == 1
    disp('s and h are inverse in mod phiM')
else
    disp('s and h are not inverse of each other')
end

% now we start encryption***************
% Generate 1000 numbers And Encrypt them with public key
    M =[];
    C =[];
    P = [];

    for i=1:20
       m = randi([2^1,2^13],1,1);
       M = [M,m];
    end
  % Encrypt with public key
    tic
    for i=1:20
       b = myMod(M(i),s,n);
       C = [C,b];
    end
    EncryptionTime = toc;
%  % Decrypt the encrypted number with private key
    tic
    for i=1:20
       c = myMod(C(i),h,n);
       P = [P,c];
    end
    DecryptionTime = toc;
    
% we display the last 20 numbers
disp('These are the original numbers')
M(1,13:20)
disp('These are the encrypted numbers')
C(1,13:20)
disp('These are the decrypted numbers')
P(1,13:20)
disp('The encryption took: ')
EncryptionTime
disp(' sec')
disp('The decryption took: ')
DecryptionTime
disp(' sec')
disp(s)
disp(h)


%************END******************